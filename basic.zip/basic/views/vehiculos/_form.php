<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model app\models\Vehiculos */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="vehiculos-form">

    <?php $form = ActiveForm::begin(); ?>

    <?= $form->field($model, 'ID_VEHICULO')->textInput() ?>

    <?= $form->field($model, 'ID_CHOFER')->textInput() ?>

    <?= $form->field($model, 'MARCA')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'MODELO')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'ANIO')->textInput() ?>

    <?= $form->field($model, 'PLACA')->textInput(['maxlength' => true]) ?>

    <div class="form-group">
        <?= Html::submitButton($model->isNewRecord ? 'Create' : 'Update', ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
