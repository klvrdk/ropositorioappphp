<?php

return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=localhost;dbname=gestionvehiculo',
    'username' => 'root',
    'password' => 'root',
    'charset' => 'utf8',
];
