<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "institucion".
 *
 * @property integer $ID_INSTITUCION
 * @property string $NOMBRE
 * @property string $DIRECCION
 *
 * @property Chofer[] $chofers
 */
class Institucion extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'institucion';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['ID_INSTITUCION'], 'required'],
            [['ID_INSTITUCION'], 'integer'],
            [['NOMBRE'], 'string', 'max' => 50],
            [['DIRECCION'], 'string', 'max' => 150],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'ID_INSTITUCION' => 'Id  Institucion',
            'NOMBRE' => 'Nombre',
            'DIRECCION' => 'Direccion',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getChofers()
    {
        return $this->hasMany(Chofer::className(), ['ID_INSTITUCION' => 'ID_INSTITUCION']);
    }
}
