<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "chofer".
 *
 * @property integer $ID_CHOFER
 * @property integer $ID_INSTITUCION
 * @property string $CEDULA
 * @property string $NOMBRES
 * @property string $APELLIDOS
 * @property string $LICENCIA
 *
 * @property Institucion $iDINSTITUCION
 * @property Vehiculos[] $vehiculos
 */
class Chofer extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'chofer';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['ID_CHOFER'], 'required'],
            [['ID_CHOFER', 'ID_INSTITUCION'], 'integer'],
            [['CEDULA'], 'string', 'max' => 10],
            [['NOMBRES', 'APELLIDOS'], 'string', 'max' => 80],
            [['LICENCIA'], 'string', 'max' => 20],
            [['ID_INSTITUCION'], 'exist', 'skipOnError' => true, 'targetClass' => Institucion::className(), 'targetAttribute' => ['ID_INSTITUCION' => 'ID_INSTITUCION']],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'ID_CHOFER' => 'Id  Chofer',
            'ID_INSTITUCION' => 'Id  Institucion',
            'CEDULA' => 'Cedula',
            'NOMBRES' => 'Nombres',
            'APELLIDOS' => 'Apellidos',
            'LICENCIA' => 'Licencia',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getIDINSTITUCION()
    {
        return $this->hasOne(Institucion::className(), ['ID_INSTITUCION' => 'ID_INSTITUCION']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getVehiculos()
    {
        return $this->hasMany(Vehiculos::className(), ['ID_CHOFER' => 'ID_CHOFER']);
    }
}
