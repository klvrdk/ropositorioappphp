<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "vehiculos".
 *
 * @property integer $ID_VEHICULO
 * @property integer $ID_CHOFER
 * @property string $MARCA
 * @property string $MODELO
 * @property integer $ANIO
 * @property string $PLACA
 *
 * @property Chofer $iDCHOFER
 */
class Vehiculos extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'vehiculos';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['ID_VEHICULO'], 'required'],
            [['ID_VEHICULO', 'ID_CHOFER', 'ANIO'], 'integer'],
            [['MARCA', 'MODELO'], 'string', 'max' => 30],
            [['PLACA'], 'string', 'max' => 10],
            [['ID_CHOFER'], 'exist', 'skipOnError' => true, 'targetClass' => Chofer::className(), 'targetAttribute' => ['ID_CHOFER' => 'ID_CHOFER']],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'ID_VEHICULO' => 'Id  Vehiculo',
            'ID_CHOFER' => 'Id  Chofer',
            'MARCA' => 'Marca',
            'MODELO' => 'Modelo',
            'ANIO' => 'Anio',
            'PLACA' => 'Placa',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getIDCHOFER()
    {
        return $this->hasOne(Chofer::className(), ['ID_CHOFER' => 'ID_CHOFER']);
    }
}
